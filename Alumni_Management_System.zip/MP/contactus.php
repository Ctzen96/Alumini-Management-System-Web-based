<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">	
<style>
table,th,td {
    border:1px;
    font-size:20px;
}
.fa {
  padding: 20px;
  font-size: 30px;
  width: 50px;
  text-align: center;
  text-decoration: none;
  margin: 5px 2px;
}
.fa:hover {
    opacity: 0.7;
}
.fa-facebook {
  background: #3B5998;
  color: white;
}

.fa-twitter {
  background: #55ACEE;
  color: white;
}

.fa-google {
  background: #dd4b39;
  color: white;
}

.fa-linkedin {
  background: #007bb5;
  color: white;
}

.fa-youtube {
  background: #bb0000;
  color: white;
}

.fa-instagram {
  background: #125688;
  color: white;
}

.fa-pinterest {
  background: #cb2027;
  color: white;
}
p.p1 {

  font-size:30px;
  font-family:"Times New Roman", Times, serif;
  

}
</style>
</head>
<body>
	<?php include 'header.php'; ?><style>
        <?php include 'content.css'; ?></style>    
<div class="container">
<div class="title">Contact Us</div>
	<div class="boxed">
        <h1 id="Contact">Contact</h1></div>
        <p1>Institute of Postgraduate Studies,
           University Malaysia Pahang
           Lebuhraya Tun Razak,Gambang
           Kuantan,Pahang
           26300
           Malaysia</p1>
        <br></br>
        <p1>+609 549 3197
           <br></br>
           +609 549 3198
           <br></br>
           +609 549 3199
           <br></br>
           +609 549 3201
           <br></br>
        </p1>
        <br></br>
        <p1>+609 549 3190
        </p1>
        <br></br>
        <p1>http://ips.ump.edu.my</p1>
      
</div>
</table>
<center>
<a href="https://web.facebook.com/ump.fskkp/?ref=br_rs" class="fa fa-facebook"></a>
<a href="https://twitter.com/fskkp?lang=en" class="fa fa-twitter"></a>
<a href="https://www.instagram.com/umpmalaysia/" class="fa fa-instagram"></a>
</center> 
	 
</body>
</html>