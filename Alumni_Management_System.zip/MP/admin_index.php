<html>
<body>
<?php include 'admin_header.php'; ?><style><?php include 'content.css'; ?></style>
</body>
</html>