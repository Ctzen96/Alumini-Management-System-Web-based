<footer class="footer">
  <div class="container">
     <div class="row">  
        <div class="col-sm-12 text-center">
		    <div class="social-icon">
		      <a href=""><i class="fa fa-facebook"></i></a>
			  <a href=""><i class="fa fa-twitter"></i></a>
			  <a href=""><i class="fa fa-google-plus"></i></a>
			  <a href=""><i class="fa fa-pinterest"></i></a>
			  <a href=""><i class="fa fa-linkedin"></i></a>		 
			  <a href=""><i class="fa fa-youtube-square"></i></a>
			</div>
		</div>
     </div>
  </div>
  </footer>