<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="footercss.css" rel="stylesheet">
</head>

<body>
	
	<div class="footer">
	<table align="center">
	<tr>
		<th>WEB INFORMATION</th>
		<th>CONTACT US</th>
		<th>SS</th>
	</tr>
	<tr>
		<td>CARE UTHM is not responsible for any damage/loss caused by the data obtained from the portal site.</td>
		<td>Centre of Alumni Advancement and Relations (CARE)
			UTHM 86400 Parit Raja Batu Pahat Johor</td>
		<td>Centre of Alumni Advancement and Relations (CARE)
			UTHM 86400 Parit Raja Batu Pahat Johor</td>
	</tr>
	<tr>
		<td>Best display: Firefox 30 and above/Internet Explorer 8 and above/Chrome version 40 and above with the resolution of 1024 x 768.</td>
		<td>No. Tel: 07-453 7879 / 7918 / 7873 / 7876 / 7819
			No. Fax: 07-453 7878
			Email: alumni@uthm.edu.my</td>
		<td>Email *</td>
	</tr>
	</div>
	</table>
	<div class="bottom">
	<table align="center">
	<tr>
		<td class="copyright" style="text-align:center">Copyright &copy;</td>
	</tr>
	</table>
	</div>
	

</body>
</html>